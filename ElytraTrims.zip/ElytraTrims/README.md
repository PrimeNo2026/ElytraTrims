# ElytraTrims

Ermöglicht Armor Trims auf Elytras (Schmiedetisch: Elytra + Trim-Vorlage + Material).

## Installation
1. `ElytraTrims-1.0.0.jar` in den `plugins`-Ordner, Server starten.
2. Das Plugin legt `world/datapacks/ElytraTrims` an. Danach den Server **einmal neu starten**.
3. Resource-Pack (`ElytraTrims-ResourcePack.zip`) irgendwo hosten (z. B. GitHub-Release) und in der
   `config.yml` bei `resource-pack.url` eintragen (SHA1 optional), dann `/elytratrims reload`.
   Alternativ in der `server.properties` bei `resource-pack` / `resource-pack-sha1`.
4. Ohne Resource-Pack bekommt die Elytra den Trim (Tooltip), aber die Flügel zeigen kein Muster.

## Befehl
- `/elytratrims status` – zeigt, ob das Datapack aktiv ist
- `/elytratrims reload` – Config neu laden

## Hinweise
- Die Muster im Resource-Pack (`resourcepack/assets/minecraft/textures/trims/entity/wings/<muster>_<material>.png`,
  128x64) sind einfache selbst gezeichnete Designs und können durch eigene PNGs ersetzt werden.
- Falls Minecraft meldet, das Pack sei zu alt/neu: `pack_format` in der `pack.mcmeta` anpassen.
