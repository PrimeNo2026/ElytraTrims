package de.elytratrims;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;
import java.util.Locale;

/**
 * Elytras dürfen im Schmiedetisch nur Trims bekommen, wenn sie im Item-Tag "trimmable_armor" stehen.
 * Das Plugin legt dafür ein kleines Datapack in den Welt-Ordner. Den Rest (Anwenden der Trims)
 * macht Minecraft selbst.
 */
public final class ElytraTrimsPlugin extends JavaPlugin implements Listener {

    private static final String PACK_NAME = "ElytraTrims";

    private static final String MCMETA = """
            {
              "pack": {
                "description": "ElytraTrims - erlaubt Trims auf Elytras",
                "pack_format": 88,
                "min_format": 48,
                "max_format": 999,
                "supported_formats": { "min_inclusive": 48, "max_inclusive": 999 }
              }
            }
            """;

    private static final String TAG = """
            {
              "replace": false,
              "values": [
                "minecraft:elytra"
              ]
            }
            """;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);

        boolean changed = installDatapack();
        if (changed) {
            getLogger().warning("Das Datapack '" + PACK_NAME + "' wurde installiert/aktualisiert. "
                    + "Bitte den Server EINMAL NEU STARTEN, damit Elytras trimmbar werden.");
        } else {
            getLogger().info("Datapack-Status: " + datapackStatus());
        }
    }

    // ------------------------------------------------------------- Datapack

    private boolean installDatapack() {
        File dir = new File(Bukkit.getWorlds().get(0).getWorldFolder(), "datapacks/" + PACK_NAME);
        try {
            boolean a = writeIfDifferent(new File(dir, "pack.mcmeta"), MCMETA);
            boolean b = writeIfDifferent(new File(dir, "data/minecraft/tags/item/trimmable_armor.json"), TAG);
            return a || b;
        } catch (IOException e) {
            getLogger().severe("Datapack konnte nicht geschrieben werden: " + e.getMessage());
            return false;
        }
    }

    private static boolean writeIfDifferent(File file, String content) throws IOException {
        if (file.exists() && Files.readString(file.toPath(), StandardCharsets.UTF_8).equals(content)) {
            return false;
        }
        file.getParentFile().mkdirs();
        Files.writeString(file.toPath(), content, StandardCharsets.UTF_8);
        return true;
    }

    private String datapackStatus() {
        try {
            var pack = Bukkit.getDatapackManager().getPack("file/" + PACK_NAME);
            if (pack == null) {
                return "nicht gefunden (Server neu starten)";
            }
            return pack.isEnabled() ? "aktiv"
                    : "gefunden, aber nicht aktiviert (/datapack enable \"file/" + PACK_NAME + "\")";
        } catch (Exception | LinkageError e) {
            return "unbekannt";
        }
    }

    // --------------------------------------------------------- Resource-Pack

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        String url = getConfig().getString("resource-pack.url", "").trim();
        if (url.isEmpty()) {
            return;
        }
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!player.isOnline()) {
                return;
            }
            byte[] hash = parseHash(getConfig().getString("resource-pack.sha1", ""));
            String promptText = getConfig().getString("resource-pack.prompt", "");
            Component prompt = promptText.isBlank() ? null : Component.text(promptText);
            player.setResourcePack(url, hash, prompt, getConfig().getBoolean("resource-pack.force", false));
        }, 20L);
    }

    private static byte[] parseHash(String hex) {
        String h = hex.trim();
        if (h.length() != 40) {
            return null;
        }
        byte[] out = new byte[20];
        try {
            for (int i = 0; i < 20; i++) {
                out[i] = (byte) Integer.parseInt(h.substring(i * 2, i * 2 + 2), 16);
            }
        } catch (NumberFormatException e) {
            return null;
        }
        return out;
    }

    // ---------------------------------------------------------------- Befehl

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("elytratrims.admin")) {
            sender.sendMessage(Component.text("Dafür hast du keine Berechtigung.", NamedTextColor.RED));
            return true;
        }
        String sub = args.length == 0 ? "status" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "status" -> {
                sender.sendMessage(Component.text("Datapack: " + datapackStatus(), NamedTextColor.YELLOW));
                String url = getConfig().getString("resource-pack.url", "").trim();
                sender.sendMessage(Component.text("Resource-Pack-URL in der Config: "
                        + (url.isEmpty() ? "nicht gesetzt" : url), NamedTextColor.YELLOW));
            }
            case "reload" -> {
                reloadConfig();
                sender.sendMessage(Component.text("Config neu geladen.", NamedTextColor.GREEN));
            }
            default -> sender.sendMessage(Component.text("/elytratrims <status|reload>", NamedTextColor.YELLOW));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1 && sender.hasPermission("elytratrims.admin")) {
            return List.of("status", "reload");
        }
        return List.of();
    }
}
